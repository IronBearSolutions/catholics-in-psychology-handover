'use strict';
(() => {
  const pages = ['home','about','calendar','enquire','privacy'];
  const titles = {home:'Catholics in Psychology | UK & Ireland',about:'About | Catholics in Psychology',calendar:'Events | Catholics in Psychology',enquire:'Register your interest | Catholics in Psychology',privacy:'Information & privacy | Catholics in Psychology'};
  const main = document.getElementById('main');
  function showPage(moveFocus = false) {
    const hash = location.hash.slice(1);
    if (hash === 'main') { main.focus({preventScroll:true}); return; }
    const requested = ({events:'calendar',interest:'enquire'})[hash] || hash;
    const page = pages.includes(requested) ? requested : 'home';
    document.querySelectorAll('.page').forEach(section => { section.hidden = section.id !== page; });
    document.querySelectorAll('[data-nav]').forEach(link => {
      if (link.dataset.nav === page) link.setAttribute('aria-current','page');
      else link.removeAttribute('aria-current');
    });
    document.title = titles[page];
    window.scrollTo({top:0,behavior:'instant'});
    if (moveFocus) main.focus({preventScroll:true});
  }
  window.addEventListener('hashchange', () => showPage(true));
  showPage();
  const today = new Date();
  const todayKey = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  document.getElementById('year').textContent = today.getFullYear();
  const events = Array.isArray(window.CIP_EVENTS) ? window.CIP_EVENTS : [];
  const upcoming = event => Boolean(event.date && event.date >= todayKey);
  const ordered = [...events].sort((a,b) => b.sortDate.localeCompare(a.sortDate));
  function element(tag,className,value) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (value) node.textContent = value;
    return node;
  }
  function eventLink(event) {
    const link = element('a','text-link','Programme & booking ↗');
    link.href = event.url; link.target = '_blank'; link.rel = 'noopener noreferrer';
    link.setAttribute('aria-label',`Programme and booking for ${event.title} (opens in a new tab)`);
    return link;
  }
  function renderEvents(filter) {
    const list = document.getElementById('events-list'); list.replaceChildren();
    document.querySelectorAll('[data-filter]').forEach(button => button.setAttribute('aria-pressed',String(button.dataset.filter === filter)));
    let selected = ordered.filter(event => filter === 'all' || (filter === 'upcoming' ? upcoming(event) : !upcoming(event)));
    if (filter === 'upcoming') selected = selected.reverse();
    if (!selected.length) {
      const empty = element('div','empty-events');
      empty.append(element('h3','','Our next gathering will be announced here.'),element('p','','Register your interest to connect with the organisers about future activities.'));
      list.append(empty);
    }
    selected.forEach(event => {
      const article = element('article','event-entry'); const date = element('div','event-date');
      date.setAttribute('aria-label',`${event.day === '—' ? '' : event.day + ' '}${event.month} ${event.year}`);
      date.append(element('span','month',event.month),element('span','day-number',event.day),element('span','event-year',event.year));
      const body = element('div','event-body');
      body.append(element('p','event-label',`${event.type} · ${upcoming(event) ? 'Upcoming' : 'Past event'}`),element('h3','',event.title),element('p','event-place',event.location),element('p','event-description',event.description));
      if (event.url) body.append(eventLink(event));
      article.append(date,body); list.append(article);
    });
  }
  document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => renderEvents(button.dataset.filter)));
  renderEvents('upcoming');
  const feature = document.getElementById('featured-event'); const next = ordered.filter(upcoming).reverse()[0];
  if (next) {
    feature.append(element('span','feature-date',`${Number(next.day)} ${next.month} ${next.year} · London`),element('h3','',next.title),element('p','',next.location));
    if (next.url) feature.append(eventLink(next));
  } else {
    feature.append(element('span','feature-date','Conferences & webinars'),element('h3','','The conversation continues.'),element('p','','Explore earlier gatherings and register your interest in the network’s future activities.'));
    const link = element('a','text-link','View our events →'); link.href='#calendar'; feature.append(link);
  }
})();
